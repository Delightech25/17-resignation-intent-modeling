import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

# Generate synthetic balanced dataset
np.random.seed(42)

data_size = 1000

data = pd.DataFrame({
    "Age": np.random.randint(20, 60, data_size),
    "MonthlyIncome": np.random.randint(20000, 150000, data_size),
    "JobSatisfaction": np.random.randint(1, 5, data_size),
    "WorkLifeBalance": np.random.randint(1, 5, data_size),
    "YearsAtCompany": np.random.randint(0, 20, data_size),
    "OverTime": np.random.randint(0, 2, data_size),
    "Promotion": np.random.randint(0, 2, data_size),
    "DistanceFromHome": np.random.randint(1, 50, data_size)
})

# Create smart target logic
data["Resignation"] = (
    (data["JobSatisfaction"] <= 2) |
    (data["WorkLifeBalance"] <= 2) |
    (data["OverTime"] == 1) |
    (data["Promotion"] == 0)
).astype(int)

X = data.drop("Resignation", axis=1)
y = data["Resignation"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = LogisticRegression()
model.fit(X_scaled, y)

# Save model & scaler
pickle.dump(model, open("model.pkl", "wb"))
pickle.dump(scaler, open("scaler.pkl", "wb"))

print("✅ Model trained successfully!")