from flask import Flask, render_template, request, redirect, url_for, session, flash
import os
import json
import pickle
import numpy as np
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__)
app.secret_key = "supersecretkey123"

USER_FILE = "users.json"
HISTORY_FILE = "history.json"

# ==========================
# Helper Functions
# ==========================

def load_users():
    if not os.path.exists(USER_FILE):
        return {}
    with open(USER_FILE, "r") as f:
        return json.load(f)

def save_users(users):
    with open(USER_FILE, "w") as f:
        json.dump(users, f, indent=4)

def load_history():
    if not os.path.exists(HISTORY_FILE):
        return []
    with open(HISTORY_FILE, "r") as f:
        return json.load(f)

def save_history(history):
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f, indent=4)

# ==========================
# Home
# ==========================

@app.route("/")
def home():
    if "user" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

# ==========================
# Register
# ==========================

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        users = load_users()

        if username in users:
            flash("Username already exists!")
            return redirect(url_for("register"))

        users[username] = {
            "password": generate_password_hash(password)
        }

        save_users(users)
        flash("Registration Successful! Please Login.")
        return redirect(url_for("login"))

    return render_template("register.html")

# ==========================
# Login
# ==========================

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        users = load_users()

        if username in users:
            stored_password = users[username]["password"]
            if check_password_hash(stored_password, password):
                session["user"] = username
                return redirect(url_for("dashboard"))

        flash("Invalid Credentials!")

    return render_template("login.html")

# ==========================
# Dashboard + Prediction
# ==========================

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():

    if "user" not in session:
        return redirect(url_for("login"))

    result = None
    probability = None
    advice = None

    if request.method == "POST":

        try:
            # Load model safely
            if not os.path.exists("model.pkl") or not os.path.exists("scaler.pkl"):
                result = "Model Files Missing"
                advice = "model.pkl or scaler.pkl not found in project folder."
            else:
                model = pickle.load(open("model.pkl", "rb"))
                scaler = pickle.load(open("scaler.pkl", "rb"))

                age = int(request.form["age"])
                income = int(request.form["income"])
                job_sat = int(request.form["job_satisfaction"])
                wlb = int(request.form["work_life_balance"])
                years = int(request.form["years_at_company"])
                overtime = int(request.form["overtime"])
                promotion = int(request.form["promotion"])
                distance = int(request.form["distance"])

                features = np.array([[age, income, job_sat, wlb,
                                      years, overtime, promotion, distance]])

                features_scaled = scaler.transform(features)

                prediction = model.predict(features_scaled)[0]
                probability = model.predict_proba(features_scaled)[0][1] * 100
                probability = round(probability, 2)

                if prediction == 1:
                    result = "High Risk of Resignation"
                    advice = "Employee may resign soon. HR intervention recommended."
                else:
                    result = "Low Risk of Resignation"
                    advice = "Employee engagement looks healthy."

                # Save history
                history = load_history()
                history.append({
                    "username": session["user"],
                    "datetime": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "risk": result,
                    "probability": probability
                })
                save_history(history)

        except Exception as e:
            result = "Prediction Error"
            advice = str(e)

    # Load user history
    history = load_history()
    user_history = [h for h in history if h["username"] == session["user"]]

    return render_template("dashboard.html",
                           username=session["user"],
                           result=result,
                           probability=probability,
                           advice=advice,
                           history=user_history)

# ==========================
# Logout
# ==========================

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))

# ==========================
# Run
# ==========================

if __name__ == "__main__":
    app.run(debug=True)